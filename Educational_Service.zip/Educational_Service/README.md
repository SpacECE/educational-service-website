# Real-Estate
Project which shows various flats and properties for the users and builders. 
The project is created using PHP,HTML,CSS,BootStrap, JavaScript, JQuery in
 front end and PhpMyAdmin in the back end. 
 Various SQL commands are used along with UI .
